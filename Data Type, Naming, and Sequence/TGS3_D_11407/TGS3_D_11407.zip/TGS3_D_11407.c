#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>

// Nama		: Alexis Divasonda Sigat Ngaing
// NPM		: 210711407
// Kelas	: D

int main() {
	char nama, tipe, jenis[20];
	float kecepatan, mean;
	int hargaTiket, jarak,  penumpang = 100, model = 12131, keuntungan, biayaOperasional, biayaUp, kecepatanTerendah, kecepatana, kecepatanb, kecepatanc, hargaa, hargab, hargac, jumlah, jmlha, jmlhb, jmlhc;
	bool boolean;
	
	printf("\n===[ WELCOME TO PT AKI WAKANDA ]===");
	printf("\n\tInput your data");
	
	printf("\n\nKereta Api 1 : ");
	printf("\n\tNama			: "); scanf("%s", &nama);
	printf("\tModel			: %d", model);
	printf("\n\tTipe			: A");
	printf("\n\tJenis 			: "); fflush(stdin); gets(jenis);
	printf("\tHarga			: "); scanf("%d", &hargaa);
	printf("\tKecepatan Maksimum	: "); scanf("%d", &kecepatana);
	
	jmlha = hargaa + (hargaa * 0.11);
			printf("\n\t\t[Harga Kereta : Rp %d ,-]",jmlha);
	
	printf("\n\nKereta Api 2 : ");
	printf("\n\tNama			: "); scanf("%s", &nama);
	printf("\tModel			: %d", model++);
	printf("\n\tTipe			: B");
	printf("\n\tJenis			: "); fflush(stdin); gets(jenis);
	printf("\tHarga			: "); scanf("%d", &hargab);
	printf("\tKecepatan Maksimum	: "); scanf("%d", &kecepatanb);
	
	jmlhb = hargab + (hargab * 0.11);
			printf("\n\t\t[Harga Kereta : Rp %d ,-]", jmlhb);
	
	printf("\n\nKereta Api 3 : ");
	printf("\n\tNama			: "); scanf("%s", &nama);
	printf("\tModel			: %d", model++);
	printf("\n\tTipe			: C");
	printf("\n\tJenis			: "); fflush(stdin); gets(jenis);
	printf("\tHarga			: "); scanf("%d", &hargac);
	printf("\tKecepatan Maksimum	: "); scanf("%d", &kecepatanc);
	
	jmlhc = hargac + (hargac * 0.11);	
			printf("\n\t\t[Harga Kereta : Rp %d ,-]", jmlhc);
	
	jumlah = jmlha + jmlhb + jmlhc;
	kecepatan = kecepatana + kecepatanb + kecepatanc;
	mean = kecepatan/3;
	
	printf("\n\n\t===[ Tampil Data ]===");
	printf("\n\tJumlah kereta		: 3");
	printf("\n\tTotal harga kereta	: Rp %d", jumlah);
	printf("\n\tKecepatan rata-rata 	: %.2f km/h", mean);
	
	printf("\n\n\t===[ Perkiraan Untung atau Tidak ]===");
	printf("\n\tHarga tiket		: "); scanf("%d", &hargaTiket);
	printf("\tJarak	(km)		: "); scanf("%d", &jarak);
	
	keuntungan = hargaTiket * penumpang;
	biayaOperasional = jarak * 1000000;
	
	printf("\tKeuntungan		: Rp %d", keuntungan);
	printf("\n\tBiaya operasional 	: Rp %d", biayaOperasional);
	
	boolean = biayaOperasional < keuntungan;
	printf("\n\tApakah untung?		: %d", boolean);
	
	printf("\n\n\t===[ Upgrade Kecepatan ]===");
	printf("\n\tKereta dengan kecepatan terendah akan bernilai 1");
	
	boolean = kecepatana < kecepatanb && kecepatanb < kecepatanc;
	printf("\n\tKereta Api 1		: %d", boolean);
	boolean = kecepatanb < kecepatanc;
	printf("\n\tKereta Api 2		: %d", boolean);
	boolean = kecepatanc < kecepatanb;
	printf("\n\tKereta Api 3		: %d", boolean);
	
	biayaUp = jumlah * 0.03;
	
	printf("\n\tBiaya Upgrade		: Rp %d", biayaUp);

	return 0;
}
